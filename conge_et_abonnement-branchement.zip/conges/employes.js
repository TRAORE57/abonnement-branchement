const { Client, logger } = require('camunda-external-task-client-js');
const open = require('open');
// configuration pour le client:
// - 'baseUrl': URL du Process Engine
// - 'logger': utilitaire pour enregistrer automatiquement les événements importants
// - 'asyncResponseTimeout': long délai d'interrogation (puis une nouvelle requête sera émise)
const config = { baseUrl: 'http://localhost:8080/engine-rest', use: logger, asyncResponseTimeout: 10000 };

// create a Client instance with custom configuration
const client = new Client(config);

// rejet formulaire
client.subscribe('messageRej', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredejours = task.variables.get('nombredejours');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}. VOTRE DEMANDE A ETE REJETE 
  			   CAR VOUS DEMANDEZ PLUS DE 14 JOURS DE CONGES. MERCI DE MODIFIER 
  		LA VALEUR '${nombredejours}' ENTREE LORS DU REMPLISSAGE DU FORMULAIRE`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});

// accepter demande 
client.subscribe('approuve', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredejours = task.variables.get('nombredejours');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}; VOTRE DEMANDE A ETE ACCORDEE. 
  			   NOUS VOUS SOUHAITONS DE PASSER DE TRES BON CONGES PENDANT LES '${nombredejours}' JOURS`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});
//REFUS DE LA DAMANDE 
client.subscribe('messageRefus', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nom = task.variables.get('nom');
  const nombredejours = task.variables.get('nombredejours');
  const motif = task.variables.get('motif');
// AFFICHAGE D'INFORMATIONS 
  console.log(`BONJOUR MOONSIEUR / MADAME ${nom}; VOTRE DEMANDE DE 
  			   CONGES DE '${nombredejours}' JOURS  A ETE REFUSEE PAR 
  			   LE DRH.
           MOTIF : ${motif}`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});
//gestion d'erreru
client.subscribe('messageErreur', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nombredejours = task.variables.get('nombredejours');
// AFFICHAGE D'INFORMATIONS 
  console.log(`DESOLE, VOUS AVEZ SAISIS '${nombredejours}' JOURS  MERCI DE REMPLIR CORRECTEMENT`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});