const { Client, logger } = require('camunda-external-task-client-js');
const open = require('open');
// configuration pour le client:
// - 'baseUrl': URL du Process Engine
// - 'logger': utilitaire pour enregistrer automatiquement les événements importants
// - 'asyncResponseTimeout': long délai d'interrogation (puis une nouvelle requête sera émise)
const config = { baseUrl: 'http://localhost:8080/engine-rest', use: logger, asyncResponseTimeout: 10000 };

const client = new Client(config);

// client pas d'accord
client.subscribe('annulee', async function({ task, taskService }) {
  // ajout de la logique metier ici

  // Obtention ou recuperation d'une ou de variable de processus
  const nomprenom = task.variables.get('nomprenom');
   const cause = task.variables.get('cause');
// AFFICHAGE D'INFORMATIONS 

  console.log(`MONSIEUR / MADAME ${nomprenom}. A ANNULE SON CONTRAT D'ABONNEMENT-BRANCHEMENT.
  	MOTIF : '${cause}' ..........`);
  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});
//terminee
client.subscribe('terminee', async function({ task, taskService }) {
// ajout de la logique metier ici
// Obtention ou recuperation d'une ou de variable de processus
// AFFICHAGE D'INFORMATIONS 
const Abonne = task.variables.get('nomprenom');
const genreClient = task.variables.get('genreClient');
const telephone= task.variables.get('numerotelephone');
const Naissance = task.variables.get('dateNaissance');
const habitation= task.variables.get('habitation');
const agent= task.variables.get('agent');
const numeroCompteur= task.variables.get('numeroCompteur');
const amperage = task.variables.get('materiel');
const coutMateriel = task.variables.get('coutMateriel');
const coutMain= task.variables.get('coutMain');
const total = task.variables.get('total');
const echelonnement = task.variables.get('echelonnement');
const reglement = task.variables.get('reglement');
const datePE = task.variables.get('datePE');
const numeroPiece = task.variables.get('numeroPiece');
 console.log(` 
 NOM DE L'ABONNE : ${Abonne} 
  GENRE DE CLIENT : ${genreClient}
  DATE DE NAISSANCE : ${Naissance}
  NUMERO DE PIECE ${numeroPiece}
  NUMERO DE TELEPHONE : ${telephone}
  LIEU D'HABITATION : ${habitation}
  NUMERO DE COMPTEUR : ${numeroCompteur}
  STATUT CIE : ${agent}
  TYPE DE COMPTEUR INSTALLE : ${amperage}
  COUT DU MATERIEL : ${coutMateriel}
  COUT DE LA  MAIN D'OEUVRE : ${coutMain}
  COUT TOTAL DE L'INSTALLATION : ${total}
  ECHELONNEMENT OU FREQUENCE DE PAYEMENT : ${echelonnement}
  MODE  DE PAYEMENT OU MOYEN DE REGLEMENT : ${reglement}
  DATE D'INSTALLATION : ${datePE}`);


  //open('https://docs.camunda.org/get-started/quick-start/success');

  // finissez la tâche
  await taskService.complete(task);
});